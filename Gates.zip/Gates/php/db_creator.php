<?php
    $con = mysqli_connect("localhost","root","");
    if(mysqli_connect_errno()) {
        echo "failed".mysqli_connect_errno();
    }
    else {
        echo "done";
        echo "<br>";
    }

    $create_db="CREATE DATABASE gatesnfences";

    if(mysqli_query($con,$create_db)) {
        echo "success";
    }
    else {
        echo "faild";
    }
    mysqli_close($con);

?>
<?php

    $con = mysqli_connect("localhost","root","","gatesnfences");

    $creat_tbl = "CREATE TABLE ads(ad_id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,ad_name varchar(50),ad_description varchar(250),ad_price int(11) ,ad_category int(11) ,image longblob NOT NULL,ad_date datetime NOT NULL)";
    if (mysqli_query($con,$creat_tbl)) {
        echo "table done";
        echo "<br>";
    }
    else {
        echo "error table";
    }
?>