<?php
if(isset($_POST["submit"])){
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false){
        $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));

        $db = mysqli_connect("localhost", "root", "", "gatesnfences");

        // Check connection
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }

        $dataTime = date("Y-m-d H:i:s");
        $ad_nm = $_POST['ad_name'];
        $ad_descript = $_POST['ad_description'];
        $ad_pri = $_POST['ad_price'];
        $ad_cat = $_POST['ad_category'];

        //Insert image content into database
        $insert = $db->query("INSERT into ads(ad_name,ad_description,ad_price,ad_category,image, ad_date) VALUES ('$ad_nm','$ad_descript','$ad_pri','$ad_cat','$imgContent','$dataTime')");
        if($insert){
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        }
    }else{
        echo "Please select an image file to upload.";
    }
}
?>